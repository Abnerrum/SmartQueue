"""Demonstração isolada de TTL no Redis para apresentação SmartQueue.
Não altera as filas ou contadores reais do aplicativo.
"""
import os
import redis


def main():
    cliente = redis.Redis(
        host=os.getenv('REDIS_HOST', 'localhost'),
        port=int(os.getenv('REDIS_PORT', '6379')),
        db=int(os.getenv('REDIS_DB', '0')),
        decode_responses=True,
    )
    try:
        cliente.ping()
    except redis.RedisError as erro:
        print(f'Não foi possível conectar ao Redis: {erro}')
        print('Confira se o Docker/Redis está iniciado e a porta 6379 está liberada.')
        return

    chave = 'demo:temporaria'
    cliente.set(chave, 'A004', ex=60)
    print('Redis conectado!')
    print(f'Senha de demonstração: {cliente.get(chave)}')
    print(f'Tempo de vida (TTL): {cliente.ttl(chave)} segundos')
    print('Após 60 segundos a chave demo:temporaria expirará automaticamente.')


if __name__ == '__main__':
    main()
